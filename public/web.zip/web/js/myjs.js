
$(function () {
  'use strict';


});
